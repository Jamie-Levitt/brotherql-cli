from brotherql_cli.cli.main import app
app()